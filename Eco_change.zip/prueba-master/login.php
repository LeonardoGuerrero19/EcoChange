<?php
    require "conection.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];

        $sql = "SELECT * FROM user WHERE user_name = '$username' AND user_password = '$password'";
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) > 0) {
            // Obtener el tipo de usuario de la consulta
            $row = mysqli_fetch_assoc($result);
            $user_rol = $row['user_rol'];

            // Iniciar sesión y redirigir según el tipo de usuario
            session_start();
            $_SESSION["username"] = $username;
            $_SESSION["user_rol"] = $user_rol;

            if ($user_rol == 'usuario_registrado') {
                header("Location: index.php");
                exit();
            }
        }else {
            echo "<script> window.alert('¡Correo o contraseña incorrectos!');</script>";
        }
    }
?>