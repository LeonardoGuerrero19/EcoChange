<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <form action="" method="post">
        <label for="email">Email</label>
        <input type="email" name="email" id="" required autocomplete="off">
        <br>
        <label for="usuario">Usuario</label>
        <input type="text" name="username" id="" required autocomplete="off">
        <br>
        <label for="password">Contraseña</label>
        <input type="password" name="password" id="" required autocomplete="off">

        <div class="input-field">
            <button type="submit" name="signup">Registrar</button>
        </div>
    </form>

    <?php
        if(isset($_POST['signup'])) {
            $username = $_POST["username"];
            $email = $_POST["email"];
            $password = $_POST["password"];

            //verficar si el usuario ya existe en la db
            $sql = "SELECT * FROM user WHERE user_name = '$username'";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<script> window.alert('¡El usuario ya está registrado!');</script>";
            } else {

            // Insertar el nuevo usuario en la base de datos con tipo_usuario = 0
            $sql = "INSERT INTO user (user_name, user_email, user_password, user_rol) VALUES ('$username', '$email', '$password', 'usuario_registrado')";
            if (mysqli_query($con, $sql)) {
                echo "<script> window.alert('¡Registro Exitoso!'); window.location='register.html'</script>";
            } else {
                echo "<script> window.alert('Error al registrar al usuario: " . mysqli_error($con). "');</script>";
            }
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>